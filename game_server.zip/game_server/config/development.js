module.exports = {
  // dbconnection:'mongodb://poenghskcdj:2sEHdke3eDi83K0ds@172.232.73.254:34256/peijdnrnsajr',
  dbconnection:
    "mongodb+srv://emmanuelakwuba57:cfaxhgu5GSVBkAtu@emirace.zci1zhz.mongodb.net/bc-clone?retryWrites=true&w=majority&appName=Emirace",
};
