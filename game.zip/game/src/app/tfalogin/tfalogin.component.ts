import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tfalogin',
  templateUrl: './tfalogin.component.html',
  styleUrls: ['./tfalogin.component.css']
})
export class TfaloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
